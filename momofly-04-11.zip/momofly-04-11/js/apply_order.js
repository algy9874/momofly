// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.12.1/firebase-app.js";
import { getFirestore, collection, getDocs, query, where, getDoc, doc, Timestamp, updateDoc} from 'https://www.gstatic.com/firebasejs/9.12.1/firebase-firestore.js';

const firebaseConfig = {
    apiKey: "AIzaSyDUabwSyDWNuElAFz1HhXf7iK5gmdO0RpA",
    authDomain: "fyp-project-system.firebaseapp.com",
    projectId: "fyp-project-system",
    storageBucket: "fyp-project-system.appspot.com",
    messagingSenderId: "965001890741",
    appId: "1:965001890741:web:251834f33f9adffaa267fc",
    measurementId: "G-20PLP5P9NL"
};
const app = initializeApp(firebaseConfig);
  
function getApplyOrderUser(primaryKeyUID){
    const db = getFirestore();
    const q = query(collection(db,"orderApplication"), where("applicationOrderID","==",primaryKeyUID));
    var list = [];
    getDocs(q).then((snapshot) => {
        snapshot.docs.forEach((doc) => {
            if(doc.data()['applicantID'].length > 0){
                list.push({
                    ...doc.data(), id: doc.id
                });
                executeApplyOrderRecord(list);
            }
        });    
    }).catch(err =>{ console.log(err)});
}
function getApplyUserRecord(primaryKeyUID){
    let list = [];
    const db = getFirestore();
    const docRef = doc(db, "orderApplication", primaryKeyUID);
    getDoc(docRef).then((doc) => {
        list = doc.data();
        setDetailRecord(list);
    }).catch((error) => {});
    showDetailApply();
}
$(document).on("click", "#select-accept-btn", function(){
    getApplyOrderUser($("#fyp-order-id").val());
    showApplySelectUserBlock();
});
$(document).on("click", ".basic-apply-user-record-block", function(){
    getApplyUserRecord($(this).attr('id'));
});




function setDetailRecord(list){
    if(list['applicantName'].length <= 0){
        list['applicantName'] = '申請者沒有填寫'
    }
    $(".txt-apply-name").text("申請人名稱: " + list['applicantName']);
    $(".txtarea-apply-reason").val(list['reasonOfApplication']);
}
function showDetailApply(){
    $(".message-apply-background").removeClass("none");
    $(".apply-block").removeClass("none");
}
function showApplySelectUserBlock(){
    $(".apply-select-block").removeClass("none");
    $(".apply-background").removeClass("none");
}
function executeApplyOrderRecord(recordList){
    $(".apply-select-content").empty();
    for(let record of recordList){
        $(".apply-select-content").append(
            generateApplyItem(
            record['id'],
            calRemainingTime(record['applicationTime']),
            record['reasonOfApplication'],
            record['applicantName'])
            );
    }
}
function calRemainingTime(time){
    var nowTime = Timestamp.fromDate(new Date());
    var dateTime = (14*3600*24) - (nowTime.seconds-time.seconds);
    if(dateTime >= 86400){
        return  Math.floor(dateTime / 86400) + "日"
    }else if(dateTime >= 3600){
        return  Math.floor(dateTime / 3600) + "小時"
    }else if(dateTime <= 0){
        return "已完結";
    }
    return "發生錯誤";
}
function generateApplyItem(applyID, applyTime, applyReason, applyName){
    var isEmpty = true;
    var html2 = '';
    var text = "否";
    if(applyName.length <= 0){
        applyName = "申請者沒有填寫"
    }
    if(applyReason.length > 0){
        isEmpty = false;
        text = "是";
        var html2 = '<span class="apply-detail">查看申請原因</span>';
    }
    var html = '<div class="basic-apply-user-record-block" id="'+applyID+'">'+
    '    <div class="txt-apply apply-item-gp-1">'+
    '        <span>申請時間:</span>'+
    '        <span class="apply-time">'+applyTime+'</span>'+
    '    </div>'+
    '    <div class="txt-apply apply-item-gp-2">'+
    '        <span>是否有申請原因:</span>'+
    '        <span class="apply-is-reason">'+text+'</span>'+
    '    </div>'+
    '    <div class="txt-apply-2 apply-item-gp-1">'+
    '        <span>申請人名稱:</span>'+
    '        <span class="apply-user-name">'+applyName+'</span>'+
    '    </div>'+
    '    <div class="txt-apply-2 apply-item-gp-2">'+
    '        <span>申請編號:</span>'+
    '        <span class="apply-id">'+applyID+'</span>'+
    '    </div>'+ html2
    '    <textarea hidden id="'+applyID+'-value">'+applyReason+'</textarea>'+
    '</div>';
    return html;
}